# Hexagon submission fields

Title: The Conjectures of Ashoke Sen

Abstract: Ashoke Sen made many conjectures about string theory over thirty years: that a certain symmetry of the theory is exact, that two magnetic monopoles form a bound state, that an unstable brane decays to a vacuum with no open strings and leaves behind a dust with no pressure, that a path integral counts the states of a black hole, that the number of states of a dyon is positive. We went through all of them, thirty-six statements in all, read the papers in which they were made and the papers that tested them, and checked every reference. We say for each one whether it has been proved, whether it has passed every test without a proof, whether it was stretched beyond the case where it holds, or whether it is false. Most of the conjectures are true. Two are false: the positivity of the dyon count fails in two orbifold models, where we recompute the negative numbers exactly, and the pressureless dust is not the end state of a brane decaying unevenly, where we prove that the dust piles up to infinite density in a finite time. For everything that is still open we say what is missing.

Primary subject: hep-th (High Energy Physics - Theory)
Cross-list subjects: math-ph (Mathematical Physics); math.NT (Number Theory)
Tags: S-duality, tachyon condensation, black hole entropy, Siegel modular forms
MSC2020: 81T30; 81T13; 83C57; 11F46; 35L67; 53C26

Contributor 1 (submitting, corresponding): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliations: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India; emails itsdeep@live.com, d.bhattacharjee@erl-forschung.de, egspl@proton.me.
Sole author.

Text of the contribution, human understanding and provenance fields: to be answered by the author on the form; the paper carries no AI declaration.

Tools used: Lean 4 (v4.35.0, core only, no Mathlib); Python 3; LaTeX (REVTeX 4.2).
arXiv identifier: none (not posted on arXiv).
Formalization and code: https://github.com/creelie/paper_11, release v1.0.1, https://doi.org/10.5281/zenodo.23652641 (all versions: https://doi.org/10.5281/zenodo.23652472). The Lean file has fifty-seven theorems, each depending on no axiom or on propext alone, with no sorry and no native evaluation.

Source files or ZIP: ConjecturesOfAshokeSen_final2-tex.zip (the folder ConjecturesOfAshokeSen_final2-tex/ with main.tex, sections/, tables/ and figures/ as PNG; compiles with pdflatex -jobname=output main.tex, three passes, no BibTeX pass, all fonts embedded, 24 pages). Do not upload the Lean file or the programs here.
License: CC BY 4.0

Data availability (in the paper): the programs, the tables, the Lean 4 formalisation of the finite statements and the source of the paper are in https://github.com/creelie/paper_11, archived on Zenodo under doi:10.5281/zenodo.23652472; the catalogue is kept in the ledger format of the engine Anaxia (creelie/eBLLM, release 3.1.0), cited as software.
Funding: none. Competing interests: none.
Device folder: D:\Hexagon\24 ConjecturesOfAshokeSen (next free number; adjust if 24 is taken).
Upload order: ConjecturesOfAshokeSen_final2.pdf, ConjecturesOfAshokeSen_final2-tex.zip, HEXAGON_FORM.md. The arXiv tarball ConjecturesOfAshokeSen_final2-arxiv.tar.gz is for arXiv only.
