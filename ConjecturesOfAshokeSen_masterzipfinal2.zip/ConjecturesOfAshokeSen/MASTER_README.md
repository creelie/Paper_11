# Proving Conjectures of Ashoke Sen: F-Theory Limits, Small Black Holes and Dyon Indices

Master archive, Deep Bhattacharjee (GitHub-related contact egspl@proton.me; GitHub creelie). Code release v2.2.1, Zenodo 10.5281/zenodo.23749469; all versions 10.5281/zenodo.23652472. Earlier title: Conjectures of Ashoke Sen: Scope, Exact Tests and Analytic Limits.

- The repository at main: tex/ (source, main.pdf, 57 pages), code/ (programs and checks), lean/ (Lean 4 certificates), figures/, dist/.
- packages/hexagon/: the Hexagon upload (PDF, source zip compiled with pdflatex -jobname=output on TeX Live 2026, arXiv tarball, form, AI provenance).
- packages/final-revision/: the MDPI Preprints files and form.
