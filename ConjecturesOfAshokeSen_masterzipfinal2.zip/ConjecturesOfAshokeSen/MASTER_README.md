# Positive Dyon Indices in CHL Models and Other Conjectures of Ashoke Sen

Deep Bhattacharjee, Priyabrata Mandal and Ushashi Bhattacharya. Code release v3.3.0, Zenodo 10.5281/zenodo.23882067; all versions 10.5281/zenodo.23652472.

- The repository at release v3.3.0 with its DOI recorded: tex/ (source and main.pdf, 71 pages), code/ (programs and checks), lean/ (Lean 4 certificates), figures/, dist/ (PDF, source zip, arXiv tarball).
- packages/arxiv/: the arXiv submission (PDF, source tarball compiled with pdflatex, form fields in ARXIV_SUBMISSION.md).
