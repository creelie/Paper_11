# Conjectures of Ashoke Sen: Scope, Exact Tests and Analytic Limits

Master archive of release v2.2.0 (Zenodo 10.5281/zenodo.23747112; all versions 10.5281/zenodo.23652472), Deep Bhattacharjee.

- The repository at release v2.2.0 with the recorded DOI: tex/ (source, main.pdf), code/ (programs and checks), lean/ (Lean 4 certificates), figures/, dist/.
- packages/hexagon/: the Hexagon upload (PDF, source zip compiled with pdflatex -jobname=output on TeX Live 2026, arXiv tarball, form, provenance).
- packages/final-revision/: the MDPI Preprints files and form.
