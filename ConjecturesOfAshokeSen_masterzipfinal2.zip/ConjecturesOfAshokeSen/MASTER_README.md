# The Conjectures of Ashoke Sen: master archive

Deep Bhattacharjee. Repository https://github.com/creelie/paper_11; Zenodo concept DOI 10.5281/zenodo.23652472 (v1.0.0: 10.5281/zenodo.23652473; v1.0.1: 10.5281/zenodo.23652641).

- `main.pdf`, `tex/`: the paper and its LaTeX source (REVTeX 4.2, two columns, 24 pages).
- `code/`: the exact expansion of 1/Phi_10 and of the Siegel form of the Z_2 orbifold, with its committed output.
- `lean/`: the Lean 4 certificate, fifty-seven kernel-checked theorems, with its README.
- `figures/`: the figure generator and the three PNG figures.
- `hexagon-v1.0.1/`: the Hexagon submission package (PDF, tex zip, arXiv tarball, submission fields).
- `.github/workflows/`: the verification and release workflows; `CITATION.cff`, `.zenodo.json`, `RELEASE_NOTES.md`, `LICENSE` (MIT).
