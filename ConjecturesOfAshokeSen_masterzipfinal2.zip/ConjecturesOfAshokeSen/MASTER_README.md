# Positive Dyon Indices in CHL Models and Other Conjectures of Ashoke Sen

Master archive, Deep Bhattacharjee (GitHub-related contact egspl@proton.me; GitHub creelie). Code release v3.2.0, Zenodo 10.5281/zenodo.23807915; all versions 10.5281/zenodo.23652472.

- The repository at main: tex/ (source, main.pdf, 70 pages), code/ (programs and checks), lean/ (Lean 4 certificates), figures/, dist/.
- packages/hexagon/: the Hexagon upload, the next version of 2610.00564 (PDF, source zip compiled with pdflatex -jobname=output on TeX Live 2026, arXiv tarball, form, AI provenance).
- packages/final-revision/: the MDPI Preprints files and form.
