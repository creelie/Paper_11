# Verification of the verdict colours, 26 October 2026

Rule applied: burnt orange marks a sentence of Sen's that is false as written; soft yellow marks a sentence that holds where it was derived and fails only where it was extended, or asserts as established what is open; a scope-limited verdict with no marking means the unrestricted restatement fails but Sen's own sentence carries the needed hypothesis.

## Sources read in full (arXiv PDFs, text extracted)

1008.4209 (claim 9), hep-th/0203265 and hep-th/0204143 (claim 17), hep-th/9702165 (claim 23), hep-th/0505122 and hep-th/0411255 (claim 26), 1810.12060 (Chattopadhyaya and David 2019, the orbifold tables), 2606.17149 (the cutoff preprint, Eq. 2.7).

## Claim 9, positivity of the single-centred index

Sen's abstract: "Single centered supersymmetric black holes in four dimensions have spherically symmetric horizon and hence carry zero angular momentum. This leads to a specific sign of the helicity trace index ... We explicitly test these predictions for ... heterotic string theory on T^6, as well as in Z_N CHL models for N = 2, 3, 5, 7."
Sen's body, Section 1, lists three sources of breakdown (hair modes, additional hair from momentum, horizonless smooth solutions) and states: "So we shall proceed with the assumption that there exists some duality frame in which only single centered black hole solution -- whose only hair are the fermion zero modes associated with broken supersymmetry -- contributes to B6 in the attractor chamber."
Check performed: the exact product expansion of 1/Phi~_2 was re-run (code/siegel_dyons.py compare, 1.9 s); it gives exactly 30 negative full indices in the cone Q^2 <= 12, P^2 <= 8, Q.P <= 4 of the Z_2 toroidal orbifold and none for the heterotic string or the Z_2 CHL model; the Lean certificate (57 theorems, 4 axiom-free, 53 on propext only) passed in the repository's CI on the current head. The 117 entries of the orbifold table with Q^2 <= 12, P^2 in {0,2,4}, Q.P in {0,1,2} were compared one by one with Tables 17 to 19 of Chattopadhyaya and David: all agree except (Q^2,P^2,Q.P) = (4,2,0), printed there as -11520 while the product formula gives +11520; their own stated sign rule (-1)^{Q^2} for P^2 = 2 requires the positive value, so the printed sign is their misprint. The paper now records this.
Colour: none. The toroidal orbifolds are outside the models Sen tested, and his sentence is stated under an explicit assumption which Chattopadhyaya and David 2021 show fails there (hair beyond the fermion zero modes). Verdict scope limited stands.

## Claim 17, tachyon matter

Sen, hep-th/0203265, abstract: "classical decay of unstable D-branes in bosonic and superstring theories produces pressureless gas with non-zero energy density"; Section 5: "We now restrict to spatially homogeneous time dependent solutions for which d_i T = 0."
Sen, hep-th/0204143, abstract: "exponential fall off of the pressure at late time as the tachyon field evolves from any spatially homogeneous initial configuration towards the minimum of the potential. Classical solutions in this field theory include non-relativistic matter with arbitrary spatial distribution of energy."
Check performed: the homogeneous asymptotic is Sen's theorem (claim 16, proved); the field theory does have the exact solution T = t, Pi = f(x) with arbitrary density, so the last sentence is true; the caustic theorem (forward focusing under a compressive velocity gradient, Appendix B example t_c = 1/(a k^2)) concerns inhomogeneous data, which Sen's pressure statement excludes by the word "homogeneous". Caustics in that regime were published by Felder, Kofman and Starobinsky 2002 and Barnaby 2004.
Colour: none. No sentence of Sen's is false as written.

## Claim 23, orientifold limit

Sen, hep-th/9702165, abstract: "reduces formally to an orientifold of type IIB theory compactified on an auxiliary complex n-fold. In some cases (but not always) if the original (n+1)-fold is singular, then the auxiliary n-fold is also singular."
Colour: none. Sen calls the reduction formal and discusses the singular cases himself.

## Claim 26, Gauss-Bonnet stretching

Sen, hep-th/0505122, abstract: "the overall numerical factor does not agree with that computed from the statistical entropy except for D = 4 and D = 5. This is not surprising in view of the fact that we do not use a fully supersymmetric action in our analysis".
Colour: none. The mismatch is stated by Sen in the same abstract.

## Claim 27, quantum entropy function (yellow)

The yellow marks the assertion that supersymmetric localisation of the AdS_2 path integral reproduces the Rademacher expansion from first principles: the localisation computations reproduce the leading terms and the logarithmic correction, and the full expansion is not derived. This is the one place where something is asserted beyond what is established, so the single yellow stays.

## Eq. (2.7) of 2606.17149

Verified in the PDF: Eqs. (2.6) and (2.8) are logarithms, Eq. (2.7) prints the bare factor (g_s^{-1} lambda_S^2)^2 as a contribution to Delta ln Z_n. A notation slip, recorded in Section 19 of the paper as nonfatal; it is not a catalogue claim and receives no colour.

## Remaining claims

Claims 1 to 8, 10 to 16, 18 to 22, 24, 25, 28 to 36 carry the verdicts proved or confirmed, which assert no error, so no colour applies. H1 and H2 are heuristic and receive no verdict.

## Result

Orange: 0. Yellow: 1 (claim 27). Repository checks: Python exact-arithmetic suites pass (negative_triples 30; 82 polynomial recurrences); Lean 57 theorems passed in CI on the current head (a local run was killed by memory pressure from an unrelated build in the same container).

## Cross-check of the ChatGPT audit (SEN_ERRORS_EVIDENCE_AND_COLOUR_REASONS.md), 15:55 UTC

H1 to H5 agree with the audit above (no orange on Sen). The six alleged errors R1 to R6 refer, by the audit's own statement, to the v1.0.1 TeX. Status in the current final2, each recomputed here:

- R1 (Hessian sign). Right about v1.0.1; already fixed. Current Lemma dustflow(iii): Dv_0 has a negative eigenvalue iff the Hessian has a positive one; Theorem caustic(ii): concave profiles do not focus, a positive Hessian eigenvalue gives a finite focal time. Check: T_0 = x^2/2 gives v_0'(0) = -1, Jacobian 1 - t, focusing at t = 1; T_0 = -x^2/2 gives v_0'(0) = +1. Both agree with the current text.
- R2 (attainment). Right about v1.0.1; already fixed. Current Theorem caustic(iii) assumes M is attained and says that without attainment t_* is only an infimum; (iv) notes that periodic profiles attain it; Appendix B uses a periodic profile.
- R3 (base versus cover). Right about v1.0.1; already fixed. Current Proposition senlimitcy: dF = -chi dh is nonzero on the base, the pullback eta^2 - xi^2 chi is singular along xi = eta = 0 on the cover; the verdict says the singularity is on the cover.
- R4 (I_0^* and finite j). Right about v1.0.1; already fixed. Current Proposition i0star: with h = s h_1, eta = s^2 eta_2, chi = s^3 chi_3 the orders are (2,3,6) and j grows as eps^{-2}. Check (sympy): Delta = 9 eps^2 h_1^2 (chi_3 h_1 - eta_2^2) + O(eps^3), eps^2 j -> -20736 h_1^4/(chi_3 h_1 - eta_2^2), as the paper states.
- R5 (squared cone condition). Right about v1.0.1; already fixed, and the audit itself says the revised scan is linear. Current equation z2conditions reads 2Q^2 + P^2 >= 3 Q.P, the code uses the same, and (3,2,2) with d = -224 is among the thirty. Check: the images of the wall Q.P >= 0 under Sen's three matrices of (3.8) are Q.P <= 2Q^2, 2Q^2 - 3 Q.P + P^2 >= 0 and Q.P <= P^2, all linear, which is Sen's (3.9). New finding: Chattopadhyaya and David print the condition with 3(Q.P)^2 in their (3.25) and (4.7); the paper now says so (PR #3).
- R6 (lambda = 0). Right about v1.0.1; already fixed. Current Theorem homogeneous: "The endpoint lambda = 0 is the undeformed brane with constant nonzero pressure and is excluded from the decay assertion." Check: f(lambda = 0) = 1.

The audit's remaining remarks (Eq. 2.7 logarithm, Pius-Sen erratum, infrared problem open, Lean scope 57 finite statements against 21 of the 30 triples) agree with what the paper and its README state.
