# Verification of the highlights, release v3.0.0

Rule applied (legend in Section 1 of the paper):
- rose: a statement Sen printed that is false as printed;
- burnt orange: a statement that fails under its own hypotheses (fatal);
- yellow: what is left unproved.

## Result

- Rose: 0. Burnt orange: 0. No statement of Sen examined is wrong as printed or fatal. The quotations behind this were compared with Sen's arXiv sources (1008.4209, hep-th/0203265, hep-th/0204143, hep-th/9702165, hep-th/0505122, hep-th/0411255); the claim-by-claim reasons of v2.0.1 are kept in VERIFICATION_v2.0.1.md.
- The three misprints of Chattopadhyaya and David (1810.12060: the tables, the cone condition, and the factor E_2(2tau) of A(2tau,z) in their (3.22), which should be E_2(tau)) are theirs, not Sen's, and carry no highlight.
- Yellow: Table 5 (page 6) lists what is left unproved for claims 1, 3, 9, 10, 15, 17, 18, 23, 26, 27, 29, 32, 34, 36 and the heuristics H1, H2; each entry is highlighted in yellow in the section named.

## Closures in v2.1.0 to v2.2.1

- Claim 23: Theorem 9.5 (normal form of weak coupling, base change of order at most two) with its corollaries; full proof in Appendix G. Corollary 9.8(iii), (iv) hold when the anticanonical system has no base points; on F12 the D7 divisor contains 7C and (iii) fails. The orientifold interpretation beyond the geometry stays yellow.
- Claim 26: Theorems 10.3, 10.6 and 10.7 (two-charge entropy, Prester's completion, the forced coefficients); full proofs in Appendix G; code/verify_closures.py makes 346 checks.
- Heterotic string in D >= 6 (not a claim of Sen): Theorem 10.10 in a highlighted box. Under (A1) AdS3 x S^p x T^(7-p), p = D - 3, (A2) c_L - c_R = 12N with level N, (A3) Cardy, the value 4 pi sqrt(nN) holds iff c_R = 12N. The superconformal algebras with sixteen supercharges give a non-unitary level (p = 4, 5), no integer solution (p = 5), c_R = 12N only at a non-integer level (p = 6, 7), or no algebra at all (p = 3). Whether the complete heterotic action gives 4 pi sqrt(nw) in D >= 6 stays open and is yellow.
- Correction of our own footnote: Sen's (3.15) sets C = 1, not C = 1/8; the Gauss-Bonnet coefficient of (3.16) is 2C = alpha'/8 in his units alpha' = 16.

## Highlight audit of v2.2.1

- Rose appears only in the legend of the introduction; burnt orange nowhere in the text.
- Every row of Table 5 has its yellow passage in the section named; the yellow passages for claims 26 (the entropy function on AdS2 x S^(D-2) in every D >= 6) and 27 (the path integral beyond the semiclassical expansion) were added in this release.

## Builds

- Container TeX Live 2023: 57 pages, 0 overfull or underfull boxes, no undefined references.
- TeX Live 2026, pdflatex -jobname=output main.tex from the unzipped Hexagon folder: three passes of 3.0 to 3.3 s, 57 pages, all fonts embedded, 0 bad boxes.
- Repository CI (verify workflow): Lean 57 theorems and the Python suites on every push; release v2.2.1 built by the release workflow, Zenodo DOI 10.5281/zenodo.23749469 (record checked: title, creator Deep Bhattacharjee, version 2.2.1).

## Release v3.0.0

- Claim 9: new Theorem 5.2. In the Z2 CHL model the single-centred index is positive for every charge with P^2 = 2 and positive discriminant, and on the Gamma_1(2) orbits; full proof in Section 5.2; code/verify_chl_positivity.py makes 18 exact checks. Theorem 5.1 states Bringmann-Murthy for P^2 in {2, 4}. The yellow passage for claim 9 now reads: positivity for every magnetic charge is not proved.
- Claim 3: proved for k = 2, and for k = 3 under the metric hypothesis of Kottke-Rochon; the unrefereed Fritzsch-Kottke-Singer preprint is no longer used.
- Every result used comes from refereed publications; Sen's own papers stay cited as the statements examined.
- Rose 0, burnt orange 0, unchanged. The note under the abstract is removed.
