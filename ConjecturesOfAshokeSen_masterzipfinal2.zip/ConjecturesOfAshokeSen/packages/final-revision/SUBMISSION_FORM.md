# Submission form, MDPI Preprints (Paper 12)

**Title.** Conjectures of Ashoke Sen: Scope, Exact Tests and Analytic Limits

**Author.** Deep Bhattacharjee (corresponding; ORCID 0000-0003-0466-750X; d.bhattacharjee@erl-forschung.de, itsdeep@live.com, egspl@proton.me). Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly, University of Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal, India.

**Subject.** Physical Sciences, Theoretical and Mathematical Physics (alternative: Mathematics, Mathematical Physics).

**Keywords.** S-duality; tachyon condensation; black hole entropy; Siegel modular forms.

**MSC 2020.** 81T30; 81T13; 83C57; 11F46; 35L67; 53C26.

**Abstract (plain text).**
We examine thirty-six statements of Ashoke Sen on duality, dyon indices, tachyon condensation, F-theory and black hole entropy, and decide which are proved, which are supported but unproved, and where each stops. We prove that every weak coupling degeneration of F-theory on an elliptic Calabi-Yau variety is, after base change and rescaling, Sen's family, and that one exists exactly when -2K_B has a section. We prove that the entropy of a two-charge small black hole is fixed by one critical value for every curvature-corrected action, so that the Gauss-Bonnet truncation matches the microscopic count only in four and five dimensions and Prester's Lovelock completion is the unique one that matches it in every dimension. Exact product expansions reproduce the known negative dyon indices, and the tachyon-dust caustic concerns the pressureless equations, not the rolling solution.

**Note under the abstract (summary).** First public 25 October 2026 as release v1.0.0 of github.com/creelie/paper_11 (concept DOI 10.5281/zenodo.23652472, version 10.5281/zenodo.23652473); revised 26 October 2026 as v1.0.1 (10.5281/zenodo.23652641) and v1.1.0 (10.5281/zenodo.23656435), which corrected the charge cone (thirty negative triples) and restated two verdicts as limits of scope; set in single-column form as v2.0.0 (10.5281/zenodo.23669248), with the two misprints of Chattopadhyaya and David added in v2.0.1 (10.5281/zenodo.23670581). Release v2.1.0 (10.5281/zenodo.23746042) proved claims 23 and 26. This version, release v2.2.0 (10.5281/zenodo.23747112), defines three highlights (rose: wrong as printed; burnt orange: fatal; yellow: left unproved), lists in Table 5 what is left unproved, proves Theorem 10.10 on the central charges of the heterotic string in D >= 6, and corrects the footnote on Sen's normalisation of the Gauss-Bonnet coupling.

**Funding.** None. **Conflicts of interest.** None.

**Data availability.** Program, Lean 4 certificates, the checks of Appendix G and source in release v2.2.0 of github.com/creelie/paper_11, archived on Zenodo (10.5281/zenodo.23747112).

**Files.** ConjecturesOfAshokeSen_final2.pdf (57 pages, amsart, single column), ConjecturesOfAshokeSen-tex.zip (main.tex, sections/, tables/, figures/), ConjecturesOfAshokeSen-arxiv.tar.gz.
