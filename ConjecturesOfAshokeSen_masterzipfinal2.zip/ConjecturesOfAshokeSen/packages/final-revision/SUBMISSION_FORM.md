# Submission form, MDPI Preprints (Paper 12)

**Title.** Proving Conjectures of Ashoke Sen: F-Theory Limits, Small Black Holes and Dyon Indices

**Earlier title.** Conjectures of Ashoke Sen: Scope, Exact Tests and Analytic Limits

**Author.** Deep Bhattacharjee (corresponding; ORCID 0000-0003-0466-750X; d.bhattacharjee@erl-forschung.de, itsdeep@live.com, egspl@proton.me). Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India. GitHub-related contact: egspl@proton.me; GitHub: creelie.

**Subject.** Physical Sciences, Theoretical and Mathematical Physics (alternative: Mathematics, Mathematical Physics).

**Keywords.** S-duality; tachyon condensation; black hole entropy; Siegel modular forms.

**MSC 2020.** 81T30; 81T13; 83C57; 11F46; 35L67; 53C26.

**Abstract (plain text).**
We prove two statements of Ashoke Sen in general form and a new case of a third. Every degeneration of F-theory on an elliptic Calabi-Yau variety that is weakly coupled at the generic point of the base is, after base change and rescaling, Sen's family, and one exists exactly when -2K_B has a section. The entropy of a two-charge small black hole is fixed by one critical value for every curvature-corrected action; the Gauss-Bonnet truncation matches the microscopic count only in four and five dimensions, and Prester's Lovelock completion is the only one that matches it in every dimension. In the Z_2 CHL model the single-centred dyon index is positive for every charge with P^2 = 2. For thirty-six statements of Sen we record what is proved and what is left open.

**Version.** Release v3.0.0 (10.5281/zenodo.23789251; all versions 10.5281/zenodo.23652472). The paper has no note under the abstract; the release history is in the repository README.

**Funding.** None. **Conflicts of interest.** None.

**Data availability.** Program, Lean 4 certificates, the checks of Appendix G and of Theorem 5.2, and source in release v3.0.0 of github.com/creelie/paper_11, archived on Zenodo (10.5281/zenodo.23789251).

**Files.** ConjecturesOfAshokeSen_final2.pdf (58 pages, amsart, single column), ConjecturesOfAshokeSen-tex.zip (main.tex, sections/, tables/, figures/), ConjecturesOfAshokeSen-arxiv.tar.gz.
