# AI provenance: Positive Dyon Indices in CHL Models and Other Conjectures of Ashoke Sen

(Earlier titles: Proving Conjectures of Ashoke Sen: F-Theory Limits, Small Black Holes and Dyon Indices; Conjectures of Ashoke Sen: Scope, Exact Tests and Analytic Limits.)

Author:
- Deep Bhattacharjee, sole and corresponding author. ORCID 0000-0003-0466-750X; d.bhattacharjee@erl-forschung.de, itsdeep@live.com, egspl@proton.me (GitHub-related contact); GitHub creelie. Formerly Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India.

- Paper and source: https://github.com/creelie/Paper_11, release v3.2.0, version DOI https://doi.org/10.5281/zenodo.23807915. The concept record https://doi.org/10.5281/zenodo.23652472 lists every version.

## Result

The paper examines thirty-six statements of Ashoke Sen and the two heuristic statements of his matrix theory paper. For each it gives the original hypotheses, what was derived, the later tests and proofs, and a verdict.

- **Claim 23 (weak coupling of F-theory).** Every degeneration of F-theory on an elliptic Calabi–Yau variety that is weakly coupled at the generic point of the base is, after a base change of degree 1 or 2 and a rescaling, Sen's family f = −3h² + tη, g = −2h³ + thη − t²χ/12. Such a degeneration exists exactly when −2K_B has a section. Rigid curves of self-intersection −n lie in the zero locus of h. On a surface whose anticanonical system has no base points, the D7 singularity of a general member is a set of nodes, with 2χ(Y) = 4χ(O) + χ(D̃); without that hypothesis it fails, as the Hirzebruch surface F12 shows.
- **Claim 26 (small black holes).** For every action whose corrections are built from curvature, the entropy of the two-charge horizon is 4π√(nw)·√(R*/α′), with R* one critical value. The Gauss–Bonnet truncation gives the statistical value exactly in D = 4 and 5, as Sen states. Prester's Lovelock completion gives it in every dimension with a unique solution, and its coefficients are the only ones that do.
- **The heterotic string in D ≥ 6 (in a highlighted box; not a claim of Sen).** Assume the central-charge route of Dabholkar–Murthy and Kraus–Larsen–Shah. Then Sen's value holds if and only if c_R = 12N. The nonlinear superconformal algebras with sixteen supercharges give a non-unitary theory (D = 7, 8), or c_R ≠ 12N (D = 8, 9, 10), or no algebra at all (D = 6). So the route does not give the value in any D ≥ 6. Whether the complete heterotic action gives it remains open.
- **Claim 9, new case (Theorem 5.2).** In the Z2 CHL model the single-centred index is positive for every charge with P² = 2 and positive discriminant. The finite part of the Fourier–Jacobi coefficient (Bhand–Sen–Singh) is written in closed form (Chattopadhyaya–David, with a misprint corrected); the sign of each theta component reduces to the positivity of the coefficients of θ₃ times the weight-four Eisenstein form E₄(x)/36 − 49E₄(x²)/180 + 11E₄(x⁴)/45 of Γ₀(4), which is proved by hand. For the heterotic string the published proof (Bringmann–Murthy) covers P² ∈ {2, 4}.
- **Claim 9, second new case (Theorem 5.7).** In the Z2 CHL model the single-centred index is positive for every charge with NQ²/2 = 1 and positive discriminant, whatever the magnetic charge. The finite part of the first Fourier–Jacobi coefficient in ρ is written in closed form through Hurwitz class numbers, the theta series of D₄ and a weight-four Eisenstein series; the two Jacobi form identities behind it are closed by Sturm bounds, odd discriminants are positive term by term, and even ones follow from a lemma on products ∏(1 − x^r)^(−e_r).
- **Claim 9, the odd CHL models (Theorem 5.10).** In the Z_N CHL models with N = 3, 5, 7 the single-centred index is positive for every charge with NQ²/2 = 1 and positive discriminant, by the same route as Theorem 5.7: a closed form of the finite part of the first Fourier–Jacobi coefficient, two Jacobi form identities closed by Sturm bounds, and a sign lemma.
- **Claim 9, every charge reduced to one coefficient (Theorem 5.13, Lemma 5.14).** For N = 1, 2, 3, 5, 7 every charge whose NQ²/2 is least in its Γ₁(N) orbit lies in the set 𝒜 of Bhand–Sen–Singh, so the single-centred index of every charge is a Fourier coefficient of the finite part of a mock Jacobi form at the least NQ²/2 of its orbit. The orbits of each discriminant are listed by Gauss reduction of binary quadratic forms.
- **Size of the least charge (Proposition 5.15).** For N = 2, 3 every orbit contains such a charge with min(m, n) ≤ √(NΔ/3); for N = 5, 7 there are infinitely many orbits on which m ≥ NΔ/4 and n ≥ Δ.
- **Claim 9, bounded discriminant (Theorem 5.16, computer-assisted).** The index is positive for every charge with N(Q²P² − (Q·P)²) ≤ 1000, 1000, 100, 60 for N = 2, 3, 5, 7: 11 237, 12 276, 876 and 668 orbits, each coefficient computed from the product formula in exact integer arithmetic. The least values are 360, 27, 20 and 3.
- **A containment of Bhand–Sen–Singh (Remark 5.17).** Their statement that the set B₂ of charges with Nm ≥ n and |ℓ| ≤ 2n lies in 𝔅 ((5.65) and (B.36)) fails for N ≥ 2; an explicit pair of charges in one orbit is given. The proofs of the paper do not use it.
- **Highlights.** The paper marks three kinds of statement:
  - rose: a statement Sen printed that is false as printed;
  - burnt orange: a statement that fails under its own hypotheses (fatal);
  - yellow: what is left unproved.

  No statement of Sen examined is wrong as printed or fatal. A table lists, claim by claim, what is left unproved.
- **Exact tests.**
  - Exact product expansions reproduce the negative full dyon indices of the toroidal orbifolds: thirty charge triples in the scanned cone.
  - Three misprints of Chattopadhyaya and David are corrected.
  - The tachyon-dust caustic is given its characteristic flow and the hypotheses under which it is attained.

## Who did what

Text of the contribution: a mix of human-written and AI-generated text.

Human understanding: all parts. The author read every proof and approved the final text.

Deep Bhattacharjee chose the problem and the claims, directed the work, set the format and ran the computations. The following were produced with AI assistance under his direction:
- the proofs and the text;
- the figures;
- the Lean files;
- the Python checks and the orbit enumeration;
- the reference list.

The AI tools were Claude Opus 5.5 in Claude Code, Claude Fable 5.1 with Ultracode, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra. Every quotation of Sen was compared with his arXiv source, and every reference was checked against the publisher's, Crossref's or arXiv's record.

A ZIP of ChatGPT calculations supplied by the author proposed the reduction of each orbit to a charge of the set 𝒜 for N = 2, 3, a finite positivity check for N = 2, 3 at discriminant at most 40, and the family of orbits of Proposition 5.15(ii) for N = 5, 7; these were reproved by hand (Theorem 5.13, Lemma 5.14, Proposition 5.15) and the computation redone and extended in `code/chl_bounded.py`, and nothing in the paper rests on the ZIP.

## How the result is checked

- **Lean 4.** `lean/SenConjectures.lean` (Lean 4.34.1, no library) has fifty-seven theorems, each depending on no axiom or on `propext` alone. It recomputes the coefficient tables inside the kernel from the definitions of the theta functions, and checks the wall-crossing identities and the twenty-one negative triples with P² ≤ 4 and Q·P ≤ 2.
- **Exact arithmetic (Python).**
  - `code/siegel_dyons.py` computes every table.
  - `verify_revision.py` rechecks the thirty-triple scan.
  - `verify_infrared_estimates.py` checks the constants of Appendices E and F.
- **The closures.** `code/verify_closures.py` (sympy, mpmath) makes 346 checks of the identities and numbers of Appendix G for claims 23 and 26.
- **Theorem 5.2.** `code/verify_chl_positivity.py` (standard library) makes 18 exact checks: the closed form against the product formula for Q² ≤ 28, |Q·P| ≤ 7, the theta and Eisenstein identities (with the Sturm bound), and every value used in the proof.
- **Theorem 5.7.** `code/chl_unit_identities.py` checks the product formula and the two Jacobi form identities through x⁴⁸, beyond the Sturm bounds; `chl_unit_positivity.py` checks the sign lemmas and the values used, and `(−1)^(Δ+1) C(Δ) > 0` for Δ ≤ 1995; `chl_unit_fullcheck.py` compares the closed form with the product formula on every coefficient x^e y^ℓ with e ≤ 20, |ℓ| ≤ 42.
- **Theorem 5.10.** `code/chl_unit_odd.py` (python-flint, numpy) checks the two Jacobi form identities to their Sturm bounds, the lattices, the sign lemma and the first values for N = 3, 5, 7.
- **Theorem 5.16.** `code/chl_bounded.py` (python-flint) lists the Γ₁(N) orbits of each discriminant by Gauss reduction (Lemma 5.14), finds in each a charge of 𝒜 (Lemma 5.12, Theorem 5.13), computes its coefficient from the product formula in exact arithmetic and checks that it is positive. The range of the paper takes about an hour on four cores; its summary and the index of every orbit are `code/chl-bounded-checks.json` and `code/chl-bounded-values.json`. The default run (Δ ≤ 200, 200, 20, 20) is in the verify workflow.
- **The central-charge theorem.** It is elementary algebra and is proved in full in the box. Its four central-charge formulas are those of Kraus–Larsen–Shah, Table 2.
- **Workflow.** The verify workflow reruns the Lean and Python checks on every push.

## What is not claimed

- The identification of the weak coupling limit with a type IIB orientifold beyond its geometry is not proved. The normal form is a statement about Weierstrass curves over K(B)((ε)), the Laurent series in the parameter over the function field of B; it does not by itself describe the total space of the family.
- The statements on the nodes of the D7 divisor are not claimed when the anticanonical system has base points.
- The statement that the complete heterotic effective action gives 4π√(nw) in every D ≥ 6 is not proved. The central-charge theorem settles that route under its stated hypotheses, and those hypotheses are themselves not proved.
- Positivity of the single-centred index for every charge is not proved. For the heterotic string it is open at P² ≥ 6 outside the orbits of the proved cases. For the Z_N CHL models with N = 2, 3, 5, 7 it is proved at NQ²/2 = 1 (and for N = 2 at P² = 2) for every discriminant, and by computation for N(Q²P² − (Q·P)²) up to 1000, 1000, 100, 60; beyond that range it needs a bound on the Fourier coefficients of the finite parts φ^F_m for m ≥ 2, which is not proved. Theorem 5.16 is a finite computation, not a proof for all charges.
- The confirmed and heuristic claims of the catalogue are not proved; the table of what is left unproved names the missing step of each.
- Only refereed sources are used; results available only in unrefereed preprints are not relied on.
- The proofs are written by hand and have not yet been refereed.
