# Hexagon submission fields (version 3 of 2610.00564)

Title: Proving Conjectures of Ashoke Sen: F-Theory Limits, Small Black Holes and Dyon Indices

Upload as: a new version (v3) of https://hexagonmath.org/2610.00564 (current version v2).

Abstract: We prove two statements of Ashoke Sen in general form and two new cases of a third. Every degeneration of F-theory on an elliptic Calabi--Yau variety that is weakly coupled at the generic point of the base is, after base change and rescaling, Sen's family, and one exists exactly when $-2K_B$ has a section. The entropy of a two-charge small black hole is fixed by one critical value for every curvature-corrected action; the Gauss--Bonnet truncation matches the microscopic count only in four and five dimensions, and Prester's Lovelock completion is the only one that matches it in every dimension. In the $\mathbb Z_2$ CHL model the single-centred dyon index is positive for every charge with $P^2=2$ and for every charge with $NQ^2/2=1$. For thirty-six statements of Sen we record what is proved and what is left open.

Primary subject: hep-th (High Energy Physics - Theory)
Cross-list subjects: math-ph (Mathematical Physics); math.AG (Algebraic Geometry); math.NT (Number Theory)
Tags: S-duality, tachyon condensation, black hole entropy, Siegel modular forms
MSC2020: 81T30; 81T13; 83C57; 11F46; 35L67; 53C26

Contributor 1 (submitting, corresponding): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliations: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India; emails d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com, egspl@proton.me (GitHub-related contact); GitHub: creelie (https://github.com/creelie).
Sole author.

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.
AI provenance: AI_PROVENANCE_ConjecturesOfAshokeSen.md (tools, who did what, how each result is checked, what is not claimed).

Tools used: Claude Opus 5.5 (Claude Code), Claude Fable 5.1 with Ultracode, GPT-6.1 Sol Ultra, GPT-6 Astra Ultra; Lean 4 (v4.34.1, core only, for the finite certificates; two supplementary files against Mathlib); Python 3 (sympy, mpmath); LaTeX (amsart, single column).
Formalization and code: https://github.com/creelie/Paper_11, release v3.1.0, https://doi.org/10.5281/zenodo.23790654 (all versions: https://doi.org/10.5281/zenodo.23652472). The Lean file has fifty-seven theorems, each depending on no axiom or on propext alone; code/verify_closures.py makes 346 checks of Appendix G; code/verify_chl_positivity.py makes 18 exact checks for Theorem 5.2; code/chl_unit_identities.py, chl_unit_positivity.py and chl_unit_fullcheck.py check the identities, the closed form and the sign lemmas of Theorem 5.7; the verify workflow runs them on every push.

What is new in this version (v3):
- Theorem 5.2 (new): in the Z2 CHL model the single-centred index is positive for every charge with P^2 = 2 and Q^2 P^2 > (Q.P)^2, and on their Gamma_1(2) orbits. The proof uses the finite part of Bhand-Sen-Singh (Res. Math. Sci. 2025) and the closed form of Chattopadhyaya-David (JHEP 2019), reduces the sign of each theta component to the coefficients of theta_3 times a weight-four Eisenstein series of Gamma_0(4), and bounds them by hand.
- Theorem 5.7 (new): in the Z2 CHL model the single-centred index is positive for every charge with NQ^2/2 = 1 and Q^2 P^2 > (Q.P)^2, for every magnetic charge P, and on their Gamma_1(2) orbits. The finite part of the first Fourier-Jacobi coefficient in rho is written in closed form through class numbers, the theta series of D_4 and a weight-four Eisenstein series, from two Jacobi form identities closed by Sturm bounds; odd discriminants are positive term by term and even ones follow from a lemma on products prod (1 - x^r)^(-e_r).
- A title-page footnote gives the preprint id 2610.00564v3.
- Only refereed sources are used. Theorem 5.1 (Bringmann-Murthy) is stated with the scope of its proof, P^2 in {2, 4}; the unrefereed general-m positivity preprint, the unrefereed monopole preprint (Fritzsch-Kottke-Singer) and other preprints are no longer used. Sen's own papers stay cited as the statements examined.
- A third misprint of Chattopadhyaya-David is recorded: in their (3.22) the factor of A(2tau,z) is E_2(tau), not E_2(2tau).
- The note under the abstract is removed; the abstract is shorter.

Source files or ZIP: ConjecturesOfAshokeSen_final2-tex.zip (the folder ConjecturesOfAshokeSen_final2-tex/ with main.tex, sections/, tables/ and figures/ as PNG, 32 files, no directory entries; compiles with pdflatex -jobname=output main.tex on TeX Live 2026, three passes of about 3 s, no BibTeX pass, 62 pages, 0 overfull or underfull boxes). Do not upload the Lean file or the programs here.
License: CC BY 4.0

Data availability (in the paper): release v3.1.0 of https://github.com/creelie/Paper_11, archived on Zenodo under 10.5281/zenodo.23790654.
Funding: none. Competing interests: none.
Upload order: ConjecturesOfAshokeSen_final2.pdf, ConjecturesOfAshokeSen_final2-tex.zip, AI_PROVENANCE_ConjecturesOfAshokeSen.md, HEXAGON_FORM.md. The arXiv tarball is for arXiv only.
