# Hexagon submission fields

Title: Proving Conjectures of Ashoke Sen: F-Theory Limits, Small Black Holes and Dyon Indices

Earlier title (versions v1.0.0 to v2.2.0 and the Hexagon packages of v1.0.1 and v2.0.1): Conjectures of Ashoke Sen: Scope, Exact Tests and Analytic Limits

Abstract: We examine thirty-six statements of Ashoke Sen on duality, dyon indices, tachyon condensation, F-theory and black hole entropy, and decide which are proved, which are supported but unproved, and where each stops. We prove that every weak coupling degeneration of F-theory on an elliptic Calabi--Yau variety is, after base change and rescaling, Sen's family, and that one exists exactly when $-2K_B$ has a section. We prove that the entropy of a two-charge small black hole is fixed by one critical value for every curvature-corrected action, so that the Gauss--Bonnet truncation matches the microscopic count only in four and five dimensions and Prester's Lovelock completion is the unique one that matches it in every dimension. Exact product expansions reproduce the known negative dyon indices, and the tachyon-dust caustic concerns the pressureless equations, not the rolling solution.

Primary subject: hep-th (High Energy Physics - Theory)
Cross-list subjects: math-ph (Mathematical Physics); math.AG (Algebraic Geometry); math.NT (Number Theory)
Tags: S-duality, tachyon condensation, black hole entropy, Siegel modular forms
MSC2020: 81T30; 81T13; 83C57; 11F46; 35L67; 53C26

Contributor 1 (submitting, corresponding): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliations: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India; emails d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com, egspl@proton.me (GitHub-related contact); GitHub: creelie (https://github.com/creelie).
Sole author.

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.
AI provenance: AI_PROVENANCE_ConjecturesOfAshokeSen.md (tools, who did what, how each result is checked, what is not claimed).

Tools used: Claude Opus 5.5 (Claude Code), Claude Fable 5.1 with Ultracode, GPT-6.1 Sol Ultra, GPT-6 Astra Ultra; Lean 4 (v4.34.1, core only, for the finite certificates; two supplementary files against Mathlib); Python 3 (sympy, mpmath); LaTeX (amsart, single column).
arXiv identifier: none (not posted on arXiv).
Formalization and code: https://github.com/creelie/Paper_11, release v2.2.0, https://doi.org/10.5281/zenodo.23747112 (all versions: https://doi.org/10.5281/zenodo.23652472). The Lean file has fifty-seven theorems, each depending on no axiom or on propext alone, with no sorry and no native evaluation; code/verify_closures.py makes 318 checks of Appendix G; the verify workflow runs the Lean and Python checks on every push.

Earlier versions (named in the note under the abstract): v1.0.0 (10.5281/zenodo.23652473), v1.0.1 (10.5281/zenodo.23652641), v1.1.0 (10.5281/zenodo.23656435), v2.0.0 (10.5281/zenodo.23669248), v2.0.1 (10.5281/zenodo.23670581), v2.1.0 (10.5281/zenodo.23746042). This package supersedes the Hexagon packages of v1.0.1 and v2.0.1.

What is new in this version: claims 23 and 26 proved (Theorem 9.5, the normal form of weak coupling; Theorems 10.3, 10.6 and 10.7 on two-charge entropy; full proofs in Appendix G); three highlights defined in the introduction (rose: wrong as printed, burnt orange: fatal, yellow: left unproved), with Table 5 listing what is left unproved (no statement of Sen examined is wrong as printed or fatal); Theorem 10.10 in a highlighted box: under the central-charge route, the heterotic string gives 4 pi sqrt(nw) in D >= 6 only if c_R = 12N, which no superconformal algebra with sixteen supercharges allows; whether the complete heterotic action gives that value remains open and is marked so.

Source files or ZIP: ConjecturesOfAshokeSen_final2-tex.zip (the folder ConjecturesOfAshokeSen_final2-tex/ with main.tex, sections/, tables/ and figures/ as PNG, 32 files, no directory entries; compiles with pdflatex -jobname=output main.tex on TeX Live 2026, three passes of about 3.5 s, no BibTeX pass (the bibliography is inline), all fonts embedded, 56 pages, 0 overfull or underfull boxes). Do not upload the Lean file or the programs here. The TeX on main of the repository carries this author block; the code archive is release v2.2.0, unchanged.
License: CC BY 4.0

Data availability (in the paper): the programs, the tables, the Lean 4 certificates, the checks of Appendix G and the source of the paper are in release v2.2.0 of https://github.com/creelie/Paper_11, archived on Zenodo under 10.5281/zenodo.23747112; the catalogue is kept in the ledger format of the engine Anaxia (creelie/eBLLM, release 3.1.0), cited as software.
Funding: none. Competing interests: none.
Device folder: D:\Hexagon\24 ConjecturesOfAshokeSen (next free number; adjust if 24 is taken).
Upload order: ConjecturesOfAshokeSen_final2.pdf, ConjecturesOfAshokeSen_final2-tex.zip, AI_PROVENANCE_ConjecturesOfAshokeSen.md, HEXAGON_FORM.md. The arXiv tarball ConjecturesOfAshokeSen_final2-arxiv.tar.gz is for arXiv only.
