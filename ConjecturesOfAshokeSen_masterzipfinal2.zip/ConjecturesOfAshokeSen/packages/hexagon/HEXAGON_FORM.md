# Hexagon submission fields (next version of 2610.00564)

Title: Positive Dyon Indices in CHL Models and Other Conjectures of Ashoke Sen

Earlier title: Proving Conjectures of Ashoke Sen: F-Theory Limits, Small Black Holes and Dyon Indices

Upload as: a new version of https://hexagonmath.org/2610.00564 (v4 if v3, the v3.1.0 package, is already up; otherwise v3).

Abstract: We prove two statements of Ashoke Sen in general form and new cases of a third. Every degeneration of F-theory on an elliptic Calabi--Yau variety that is weakly coupled at the generic point of the base is, after base change and rescaling, Sen's family, and one exists exactly when $-2K_B$ has a section. The entropy of a two-charge small black hole is fixed by one critical value for every curvature-corrected action; the Gauss--Bonnet truncation matches the microscopic count only in four and five dimensions, and Prester's Lovelock completion is the only one that matches it in every dimension. In the $\mathbb Z_N$ CHL models with $N=2,3,5,7$ the single-centred dyon index of a charge is a Fourier coefficient of a mock Jacobi form at the least $NQ^2/2$ of its duality orbit; it is positive for every charge with $NQ^2/2=1$, for $N=2$ also for every charge with $P^2=2$, and, by a computation over the orbits, for every charge with $N\big(Q^2P^2-(Q\cdot P)^2\big)$ at most $1000$, $1000$, $100$, $60$. For thirty-six statements of Sen we record what is proved and what is left open.

Primary subject: hep-th (High Energy Physics - Theory)
Cross-list subjects: math-ph (Mathematical Physics); math.AG (Algebraic Geometry); math.NT (Number Theory)
Tags: S-duality, tachyon condensation, black hole entropy, Siegel modular forms
MSC2020: 81T30; 81T13; 83C57; 11F46; 35L67; 53C26

Contributor 1 (submitting, corresponding): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliations: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India; emails d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com, egspl@proton.me (GitHub-related contact); GitHub: creelie (https://github.com/creelie).
Sole author.

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.
AI provenance: AI_PROVENANCE_ConjecturesOfAshokeSen.md (tools, who did what, how each result is checked, what is not claimed).

Tools used: Claude Opus 5.5 (Claude Code), Claude Fable 5.1 with Ultracode, GPT-6.1 Sol Ultra, GPT-6 Astra Ultra; Lean 4 (v4.34.1, core only, for the finite certificates; two supplementary files against Mathlib); Python 3 (sympy, mpmath, python-flint, numpy); LaTeX (amsart, single column).
Formalization and code: https://github.com/creelie/Paper_11, release v3.2.0, https://doi.org/10.5281/zenodo.23807915 (all versions: https://doi.org/10.5281/zenodo.23652472). The Lean file has fifty-seven theorems, each depending on no axiom or on propext alone; code/verify_closures.py makes 346 checks of Appendix G; code/verify_chl_positivity.py checks Theorem 5.2; chl_unit_identities.py, chl_unit_positivity.py and chl_unit_fullcheck.py check Theorem 5.7; chl_unit_odd.py checks Theorem 5.10; chl_bounded.py proves Theorem 5.16 by computation; the verify workflow runs them on every push.

What is new in this version:
- Theorem 5.10 (new): in the Z_N CHL models with N = 3, 5, 7 the single-centred index is positive for every charge with NQ^2/2 = 1 and Q^2P^2 > (Q.P)^2, and on their Gamma_1(N) orbits, through a closed form of the finite part of the first Fourier-Jacobi coefficient and a sign lemma.
- Theorem 5.13 (new): for N = 1, 2, 3, 5, 7, every charge whose NQ^2/2 is least in its Gamma_1(N) orbit lies in the set A of Bhand-Sen-Singh, so the single-centred index of every charge is one Fourier coefficient of the finite part of a mock Jacobi form at the least NQ^2/2 of its orbit. Lemma 5.14 describes the orbits through Gauss reduction of binary quadratic forms.
- Proposition 5.15 (new): for N = 2, 3 every orbit contains such a charge with min(m, n) at most sqrt(N Delta/3); for N = 5, 7 there are infinitely many orbits on which both m and n grow linearly with Delta.
- Theorem 5.16 (new, computer-assisted): positivity for every charge with N(Q^2P^2 - (Q.P)^2) at most 1000, 1000, 100, 60 for N = 2, 3, 5, 7 (11 237, 12 276, 876 and 668 orbits; every coefficient computed in exact integer arithmetic).
- Remark 5.17 (new): the containment B_2 in B of Bhand-Sen-Singh, (5.65) and (B.36), fails for N >= 2; an explicit pair of charges in one orbit is given. Our proofs do not use it.
- Two new figures (Figures 4 and 5); title changed to match what is proved.

Source files or ZIP: ConjecturesOfAshokeSen_final2-tex.zip (the folder ConjecturesOfAshokeSen_final2-tex/ with main.tex, sections/, tables/ and figures/ as PNG, 36 files, no directory entries; compiles with pdflatex -jobname=output main.tex on TeX Live 2026, three passes of about 4 s, no BibTeX pass, 70 pages, 0 overfull or underfull boxes). Do not upload the Lean file or the programs here.
License: CC BY 4.0

Data availability (in the paper): release v3.2.0 of https://github.com/creelie/Paper_11, archived on Zenodo under 10.5281/zenodo.23807915.
Funding: none. Competing interests: none.
Upload order: ConjecturesOfAshokeSen_final2.pdf, ConjecturesOfAshokeSen_final2-tex.zip, AI_PROVENANCE_ConjecturesOfAshokeSen.md, HEXAGON_FORM.md. The arXiv tarball is for arXiv only.
